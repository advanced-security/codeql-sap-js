import cds from '@sap/cds'
const LOG = cds.log("logger");

const { Books } = cds.entities('sap.capire.bookshop')

class SampleVulnService extends cds.ApplicationService {
    init() {
	/* A sensitive info log sink. */
        LOG.info("Received: ", messageToPass); // CAP log exposure alert
    }

}
